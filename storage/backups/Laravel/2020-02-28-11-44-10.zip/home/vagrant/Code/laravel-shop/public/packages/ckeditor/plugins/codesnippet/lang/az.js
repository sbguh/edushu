﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","az",{button:"Kodun parçasını əlavə et",codeContents:"Kod",emptySnippetError:"Kodun parçasını boş ola bilməz",language:"Programlaşdırma dili",title:"Kodun parçasını",pathName:"kodun parçasını"});